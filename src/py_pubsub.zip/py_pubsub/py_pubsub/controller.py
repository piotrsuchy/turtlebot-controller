import rclpy
import tf_transformations
from math import sqrt, atan2
from random import random
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

class Controller(Node):
    def __init__(self, v_const = 2.0, wgain = 1.0, distThresh = 0.05):
        super().__init__('dist_controller')
        self.v_const = v_const
        self.wgain = wgain
        self.distThresh = distThresh
        self.target_x = None
        self.target_y = None
        self.x = 0
        self.y = 0
        self.z = 0
        self.q_x = 0
        self.q_y = 0
        self.q_z = 0
        self.q_w = 0

        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.subscriber = self.create_subscription(Odometry, 'odom', self.update_position, 10)
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def set_target_position(self, target_x, target_y):
        self.target_x = target_x
        self.target_y = target_y

    # function for reading position and orientation in a subscriber
    def update_position(self, msg):
        posit = msg.pose.pose.position
        orient = msg.pose.pose.orientation 
        self.x = posit.x
        self.y = posit.y
        self.z = posit.z
        self.q_x = orient.x
        self.q_y = orient.y
        self.q_z = orient.z
        self.q_w = orient.w
        self.calculate_velocity_and_angle()


    # publisher callback to give linear velocity and angular velocity
    # calculated in calculate_velocity function
    def publisher_callback(self):
        msg = Twist()
        msg.linear.x = self.v_const
        msg.angular.z = self.wgain
        # print(f'linear vel: {msg.linear.x}, ang. vel: {msg.angular.z}')
        # publish the linear velocity for x axis, and angular velocity for z:
        self.publisher.publish(msg)

    def timer_callback(self):
        string_to_send = 'X: {0:.2f} Y:{1:.2f} Z: {2:.2f} --- ang_x: {3:.2f}, ang_y: {4:.2f}, ang_z: {5:.2f}, ang_w: {6:.2f}'.format(self.x, self.y, self.z, self.q_x, self.q_y, self.q_z, self.q_w)
        self.get_logger().info(string_to_send)

    def calculate_velocity_and_angle(self):
        if (self.target_x is None or self.target_y is None):
            print("The target destination has not been given yet!")
        else:    
            global goal_reached
            goal_reached = False
            if goal_reached is False:
                print("1---")
                # calculate angle we need to have to reach the goal
                dx = self.target_x - self.x
                dy = self.target_y - self.y
                goal_angle = atan2(dy, dx)

                # calculate angles from quaternions, yaw is the third one (for z)
                angles = tf_transformations.euler_from_quaternion((self.q_x,self.q_y,
                                                            self.q_z,self.q_w))
                yaw = angles[2]

                # calculate angular velocity the bigger the difference, the higher the velocity:
                self.wgain = (goal_angle - yaw)*0.8


                distance_to_goal = sqrt(abs(dx**2 + dy**2))
                print(distance_to_goal)
                if distance_to_goal > self.distThresh:
                    print("1")
                    self.v_const = min(1.2, distance_to_goal*0.8)
                else:
                    self.v_const = 0.0
                    self.wgain = 0.0
                    goal_reached = True
                # publish the velocity changes
                self.publisher_callback()
            else:
                print("We arrived to the destination")


def main(args = None):
    
    rclpy.init(args=args)
    controller = Controller()
    controller.set_target_position(1, 1)
    rclpy.spin(controller)
    controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
        